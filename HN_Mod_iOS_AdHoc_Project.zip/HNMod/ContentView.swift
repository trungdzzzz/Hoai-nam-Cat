import SwiftUI
import WebKit

@main
struct HNModApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.light)
        }
    }
}

struct ContentView: View {
    @State private var isLoading = true
    @State private var loadFailed = false

    var body: some View {
        ZStack {
            WebView(
                url: URL(string: "https://skinff.top")!,
                isLoading: $isLoading,
                loadFailed: $loadFailed
            )
            .ignoresSafeArea(edges: .bottom)

            if isLoading {
                VStack(spacing: 14) {
                    Image("AppLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 88, height: 88)
                    Text("HN Mod")
                        .font(.title2.bold())
                    ProgressView()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(red: 0.05, green: 0.12, blue: 0.28))
                .foregroundStyle(.white)
            }

            if loadFailed && !isLoading {
                VStack(spacing: 12) {
                    Text("Không thể tải nội dung")
                        .font(.headline)
                    Text("Kiểm tra kết nối mạng rồi thử lại.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Button("Thử lại") {
                        NotificationCenter.default.post(name: .hnModReload, object: nil)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(24)
                .background(.regularMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .padding()
            }
        }
        .background(Color(red: 0.05, green: 0.12, blue: 0.28))
    }
}

extension Notification.Name {
    static let hnModReload = Notification.Name("HNModReload")
}

struct WebView: UIViewRepresentable {
    let url: URL
    @Binding var isLoading: Bool
    @Binding var loadFailed: Bool

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0.05, green: 0.12, blue: 0.28, alpha: 1)
        webView.scrollView.backgroundColor = webView.backgroundColor
        webView.load(URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 30))

        context.coordinator.webView = webView
        context.coordinator.reloadObserver = NotificationCenter.default.addObserver(
            forName: .hnModReload, object: nil, queue: .main
        ) { [weak webView] _ in
            webView?.reload()
        }
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        if let observer = coordinator.reloadObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        var parent: WebView
        weak var webView: WKWebView?
        var reloadObserver: NSObjectProtocol?

        init(_ parent: WebView) { self.parent = parent }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            parent.isLoading = true
            parent.loadFailed = false
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            parent.isLoading = false
            parent.loadFailed = false
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            parent.isLoading = false
            parent.loadFailed = true
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            parent.isLoading = false
            parent.loadFailed = true
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            // Keep web content inside the app. External schemes are blocked for safety.
            if let scheme = navigationAction.request.url?.scheme?.lowercased(),
               !["https", "http"].contains(scheme) {
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }
    }
}
