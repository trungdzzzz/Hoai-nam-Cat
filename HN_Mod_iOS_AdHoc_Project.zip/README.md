# HN Mod iOS project

Native SwiftUI + WKWebView wrapper for https://skinff.top.

- App display name: HN Mod
- Bundle ID: com.hoainam.hnmod
- App opens the site inside a full-screen WKWebView (no Safari address bar).
- Includes a custom HN icon.
- Includes a Codemagic workflow file (`codemagic.yaml`).

IMPORTANT: This ZIP is source code, not an IPA. Codemagic must build and sign it.

## Build with Codemagic from an iPhone

1. Upload this project to a private GitHub repository. Extract the ZIP first, then upload the contents so `HNMod.xcodeproj` and `codemagic.yaml` are at the repository root.
2. Create a Codemagic account and connect that GitHub repository.
3. In Codemagic, add an App Store Connect API integration named exactly `HNModASC`.
   - In App Store Connect > Users and Access > Integrations > App Store Connect API, create an API key.
   - Download the `.p8` file once and record the Key ID and Issuer ID.
   - Upload the key to Codemagic. Do not share the `.p8` file or private credentials in chat.
4. Ensure the app identifier `com.hoainam.hnmod` exists under your Apple Developer account. If it is already taken, change PRODUCT_BUNDLE_IDENTIFIER in the Xcode project and the bundle_identifier in codemagic.yaml to a unique ID.
5. In Codemagic, run workflow `hnmod-ios`.
6. After a successful build, download the `.ipa` from the build's Artifacts section.

This workflow uses App Store distribution signing. It is intended for App Store Connect/TestFlight distribution; installing directly from a downloaded IPA may require an appropriate distribution method and device provisioning. For direct device installation, use an Ad Hoc or Development profile with the iPhone UDID registered in the Apple Developer account.

Never give your Apple ID password, API private key, .p12 private key, or certificate password to anyone. Only enter signing material into the official Codemagic dashboard after verifying the domain.
